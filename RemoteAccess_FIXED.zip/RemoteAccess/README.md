# 📱 RemoteAccess — Android to Android Remote Control App

Control your secondary Android device from your main Android device over Wi-Fi / Hotspot.

---

## ✅ Features

| Feature              | Details                                         |
|----------------------|-------------------------------------------------|
| 🖥️ Live Screen View  | See secondary device screen in real-time        |
| 👆 Touch Control     | Tap/swipe on the screen to control remotely     |
| 📁 File Browser      | Browse, download & upload files                 |
| 🔔 Notifications     | See all notifications from secondary device     |
| 📷 Camera Stream     | View front/back camera live                     |
| 🔊 Mic Stream        | Audio forwarding (hook into CameraStreamService)|

---

## 🏗️ Project Structure

```
RemoteAccess/
├── app/src/main/
│   ├── AndroidManifest.xml
│   ├── java/com/remoteaccess/app/
│   │   ├── network/
│   │   │   └── SocketManager.kt        ← TCP communication layer
│   │   ├── services/
│   │   │   ├── RemoteServerService.kt  ← Main server (secondary device)
│   │   │   ├── ScreenCaptureService.kt ← Screen streaming
│   │   │   ├── CameraStreamService.kt  ← Camera streaming
│   │   │   └── NotificationCollectorService.kt
│   │   └── ui/
│   │       ├── MainActivity.kt         ← Mode selector
│   │       ├── ServerActivity.kt       ← Secondary device UI
│   │       ├── ClientActivity.kt       ← Main device UI (screen + controls)
│   │       ├── FileBrowserActivity.kt  ← File manager
│   │       └── NotificationsActivity.kt
│   └── res/
│       └── layouts_ALL.xml             ← All layout XML files (split into individual files)
└── app/build.gradle
```

---

## 🚀 Setup Steps

### Step 1 — Create Android Studio Project
1. Open Android Studio → New Project → **Empty Activity**
2. Package name: `com.remoteaccess.app`
3. Min SDK: **26 (Android 8)**
4. Language: **Kotlin**

### Step 2 — Copy Files
- Copy all `.kt` files into `app/src/main/java/com/remoteaccess/app/`
- Copy `AndroidManifest.xml` to `app/src/main/`
- Replace `app/build.gradle` with the provided one
- Split `layouts_ALL.xml` into individual files in `app/src/main/res/layout/`:
  - `activity_main.xml`
  - `activity_server.xml`
  - `activity_client.xml`
  - `activity_file_browser.xml`
  - `activity_notifications.xml`
  - `item_file.xml`
  - `item_notification.xml`

### Step 3 — Build & Install on BOTH Devices
```bash
./gradlew assembleDebug
adb install app/build/outputs/apk/debug/app-debug.apk
```
Install the **same APK** on both devices.

---

## 📡 How to Use

### On Secondary Device (to be controlled):
1. Open app → tap **SERVER MODE**
2. Tap **Grant Notification Access** → enable in settings
3. Tap **▶ Start Server**
4. Note your **IP address** shown on screen

### On Main Device (controller):
1. Open app → tap **CLIENT MODE**
2. Enter the **IP address** from secondary device
3. Tap **Connect**
4. You'll see the live screen — tap to control!

---

## 🔑 Permissions Required

| Permission               | Used For                |
|--------------------------|-------------------------|
| CAMERA                   | Camera streaming        |
| RECORD_AUDIO             | Mic streaming           |
| READ_EXTERNAL_STORAGE    | File browsing           |
| FOREGROUND_SERVICE       | Background operation    |
| NOTIFICATION_LISTENER    | Notification forwarding |

---

## ⚙️ Touch Control Notes

- On **non-rooted** devices: Touch simulation requires enabling **Accessibility Service**
- On **rooted** devices: Works automatically via `input tap x y` shell command

To enable on non-rooted devices, create an `AccessibilityService` that listens for touch gesture commands via broadcast and calls `dispatchGesture()`.

---

## 🔧 Customization

| Setting              | File                     | Variable         |
|----------------------|--------------------------|------------------|
| Port number          | RemoteServerService.kt   | `PORT = 54321`   |
| Screen FPS           | ScreenCaptureService.kt  | `FPS = 15`       |
| JPEG quality         | ScreenCaptureService.kt  | `JPEG_QUALITY=50`|
| Camera FPS           | CameraStreamService.kt   | `FPS = 10`       |

---

## 🔒 Security Note

This app communicates over your **local Wi-Fi/Hotspot only** (no internet required).  
For extra security, add a PIN/password handshake in `RemoteServerService.handleClient()`.
