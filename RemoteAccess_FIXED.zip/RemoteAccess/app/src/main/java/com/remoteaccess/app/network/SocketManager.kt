package com.remoteaccess.app.network

import com.google.gson.Gson
import kotlinx.coroutines.*
import java.io.*
import java.net.Socket

object PacketType {
    const val SCREEN_FRAME       = "SCREEN_FRAME"
    const val TOUCH_EVENT        = "TOUCH_EVENT"
    const val FILE_LIST_REQ      = "FILE_LIST_REQ"
    const val FILE_LIST_RES      = "FILE_LIST_RES"
    const val FILE_DOWNLOAD_REQ  = "FILE_DOWNLOAD_REQ"
    const val FILE_CHUNK         = "FILE_CHUNK"
    const val FILE_UPLOAD_REQ    = "FILE_UPLOAD_REQ"
    const val NOTIFICATION       = "NOTIFICATION"
    const val CAMERA_FRAME       = "CAMERA_FRAME"
    const val MIC_AUDIO          = "MIC_AUDIO"
    const val PING               = "PING"
    const val PONG               = "PONG"
    const val DEVICE_INFO        = "DEVICE_INFO"
    const val START_CAMERA       = "START_CAMERA"   // FIX: was missing, caused crash
    const val STOP_CAMERA        = "STOP_CAMERA"
    const val START_SCREEN       = "START_SCREEN"
    const val STOP_SCREEN        = "STOP_SCREEN"
}

data class Packet(
    val type: String,
    val payload: String = "",
    val binarySize: Int = 0
)

class SocketManager(private val socket: Socket) {

    val isConnected get() = socket.isConnected && !socket.isClosed

    private val gson = Gson()
    private val outputStream = socket.getOutputStream()
    private val inputStream  = socket.getInputStream()
    private val reader = BufferedReader(InputStreamReader(inputStream))

    var onPacketReceived: ((Packet, ByteArray?) -> Unit)? = null
    var onDisconnected: (() -> Unit)? = null

    private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())

    fun startListening() {
        scope.launch {
            try {
                while (isConnected) {
                    val line = reader.readLine() ?: break
                    if (line.isBlank()) continue                    // FIX: skip empty lines
                    val packet = try {
                        gson.fromJson(line, Packet::class.java)
                    } catch (e: Exception) { continue }             // FIX: skip malformed JSON

                    var binaryData: ByteArray? = null
                    if (packet.binarySize > 0) {
                        binaryData = ByteArray(packet.binarySize)
                        var offset = 0
                        while (offset < packet.binarySize) {
                            val read = inputStream.read(binaryData, offset, packet.binarySize - offset)
                            if (read == -1) break
                            offset += read
                        }
                    }
                    withContext(Dispatchers.Main) {
                        onPacketReceived?.invoke(packet, binaryData)
                    }
                }
            } catch (e: Exception) {
                e.printStackTrace()
            } finally {
                withContext(Dispatchers.Main) { onDisconnected?.invoke() }
                close()
            }
        }
    }

    fun sendPacket(packet: Packet, binary: ByteArray? = null) {
        if (!isConnected) return
        scope.launch(Dispatchers.IO) {                              // FIX: enforce IO thread for network calls
            try {
                val headerLine = gson.toJson(packet) + "\n"
                outputStream.write(headerLine.toByteArray(Charsets.UTF_8))
                if (binary != null && binary.isNotEmpty()) {
                    outputStream.write(binary)
                }
                outputStream.flush()
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    fun close() {
        scope.cancel()
        runCatching { socket.close() }
    }
}
