package com.remoteaccess.app.ui

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.media.projection.MediaProjectionManager
import android.net.wifi.WifiManager
import android.os.Bundle
import android.provider.Settings
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.remoteaccess.app.databinding.ActivityServerBinding
import com.remoteaccess.app.services.RemoteServerService
import com.remoteaccess.app.services.ScreenCaptureService

class ServerActivity : AppCompatActivity() {

    private lateinit var binding: ActivityServerBinding

    private val requiredPermissions = arrayOf(
        Manifest.permission.CAMERA,
        Manifest.permission.RECORD_AUDIO,
        Manifest.permission.READ_EXTERNAL_STORAGE
    )

    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { results ->
        if (results.all { it.value }) requestScreenCapture()
        else Toast.makeText(this, "Some permissions were denied", Toast.LENGTH_SHORT).show()
    }

    private val screenCaptureLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK && result.data != null) {
            startForegroundService(
                ScreenCaptureService.buildIntent(this, result.resultCode, result.data!!)
            )
            binding.tvStatus.text = "Status: Running ✅"
            Toast.makeText(this, "Server started! Share your IP with the client device.", Toast.LENGTH_LONG).show()
        } else {
            Toast.makeText(this, "Screen capture permission denied", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityServerBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.tvIpAddress.text = "Your IP: ${getLocalIp()}"
        binding.tvPort.text      = "Port: ${RemoteServerService.PORT}"

        binding.btnNotifAccess.setOnClickListener {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
        }

        binding.btnStartServer.setOnClickListener {
            // Start the socket server first
            startForegroundService(Intent(this, RemoteServerService::class.java))
            // Then request permissions + screen capture
            val missing = requiredPermissions.filter {
                ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
            }
            if (missing.isNotEmpty()) permissionLauncher.launch(missing.toTypedArray())
            else requestScreenCapture()
        }

        binding.btnStopServer.setOnClickListener {
            stopService(Intent(this, RemoteServerService::class.java))
            stopService(Intent(this, ScreenCaptureService::class.java))
            binding.tvStatus.text = "Status: Stopped"
        }
    }

    private fun requestScreenCapture() {
        val pm = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        screenCaptureLauncher.launch(pm.createScreenCaptureIntent())
    }

    private fun getLocalIp(): String = try {
        val wm = applicationContext.getSystemService(WifiManager::class.java)
        val ip = wm.connectionInfo.ipAddress
        "${ip and 0xff}.${ip shr 8 and 0xff}.${ip shr 16 and 0xff}.${ip shr 24 and 0xff}"
    } catch (e: Exception) { "N/A — check Wi-Fi" }
}
