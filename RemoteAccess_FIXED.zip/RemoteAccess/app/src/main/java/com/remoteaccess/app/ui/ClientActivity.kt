package com.remoteaccess.app.ui

import android.content.Intent
import android.graphics.BitmapFactory
import android.os.Bundle
import android.view.MotionEvent
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.google.gson.Gson
import com.remoteaccess.app.databinding.ActivityClientBinding
import com.remoteaccess.app.models.*
import com.remoteaccess.app.network.Packet
import com.remoteaccess.app.network.PacketType
import com.remoteaccess.app.network.SocketManager
import com.remoteaccess.app.services.RemoteServerService
import kotlinx.coroutines.*
import java.net.Socket

class ClientActivity : AppCompatActivity() {

    private lateinit var binding: ActivityClientBinding
    private val gson = Gson()
    private var socketManager: SocketManager? = null

    private var remoteWidth  = 1080f
    private var remoteHeight = 1920f

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityClientBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.btnConnect.setOnClickListener {
            val ip   = binding.etIpAddress.text.toString().trim()
            val port = binding.etPort.text.toString().trim().toIntOrNull()
                ?: RemoteServerService.PORT
            if (ip.isEmpty()) {
                Toast.makeText(this, "Please enter an IP address", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            connectToServer(ip, port)
        }

        binding.btnDisconnect.setOnClickListener { disconnect() }

        binding.btnFiles.setOnClickListener {
            if (socketManager == null) {
                Toast.makeText(this, "Not connected", Toast.LENGTH_SHORT).show(); return@setOnClickListener
            }
            startActivity(Intent(this, FileBrowserActivity::class.java))
        }

        binding.btnNotifications.setOnClickListener {
            startActivity(Intent(this, NotificationsActivity::class.java))
        }

        binding.btnCamera.setOnClickListener {
            socketManager?.sendPacket(
                Packet(PacketType.START_CAMERA, gson.toJson(StartCameraRequest("1")))
            ) ?: Toast.makeText(this, "Not connected", Toast.LENGTH_SHORT).show()
        }

        // Touch → remote control
        binding.ivScreenView.setOnTouchListener { v, event ->
            handleTouchOnScreen(v.width.toFloat(), v.height.toFloat(), event)
            true
        }
    }

    private fun connectToServer(ip: String, port: Int) {
        binding.tvStatus.text = "Connecting..."
        lifecycleScope.launch(Dispatchers.IO) {
            try {
                val socket = Socket(ip, port)
                socket.soTimeout = 0                        // FIX: no read timeout for streaming
                val mgr = SocketManager(socket)
                mgr.onPacketReceived = { pkt, bin -> handlePacket(pkt, bin) }
                mgr.onDisconnected = {
                    socketManager = null
                    ClientState.socketManager = null
                    runOnUiThread {
                        binding.tvStatus.text = "Disconnected"
                        Toast.makeText(this@ClientActivity, "Server disconnected", Toast.LENGTH_SHORT).show()
                    }
                }
                mgr.startListening()
                mgr.sendPacket(Packet(PacketType.PING))

                socketManager = mgr
                ClientState.socketManager = mgr

                withContext(Dispatchers.Main) {
                    binding.tvStatus.text = "Connected ✅  $ip:$port"
                }
            } catch (e: Exception) {
                withContext(Dispatchers.Main) {
                    binding.tvStatus.text = "Failed: ${e.message}"
                }
            }
        }
    }

    private fun disconnect() {
        socketManager?.close()
        socketManager = null
        ClientState.socketManager = null
        binding.tvStatus.text = "Disconnected"
    }

    private fun handlePacket(packet: Packet, binary: ByteArray?) {
        when (packet.type) {

            PacketType.SCREEN_FRAME -> {
                binary ?: return
                val meta = gson.fromJson(packet.payload, ScreenFrameMeta::class.java)
                remoteWidth  = meta.width.toFloat()
                remoteHeight = meta.height.toFloat()
                val bmp = BitmapFactory.decodeByteArray(binary, 0, binary.size) ?: return
                runOnUiThread { binding.ivScreenView.setImageBitmap(bmp) }
            }

            PacketType.CAMERA_FRAME -> {
                binary ?: return
                val bmp = BitmapFactory.decodeByteArray(binary, 0, binary.size) ?: return
                runOnUiThread { binding.ivCameraView.setImageBitmap(bmp) }
            }

            PacketType.DEVICE_INFO -> {
                val info = gson.fromJson(packet.payload, DeviceInfo::class.java)
                runOnUiThread {
                    binding.tvDeviceInfo.text = "📱 ${info.model}  |  Android ${info.androidVersion}"
                }
            }

            PacketType.NOTIFICATION -> {
                val notif = gson.fromJson(packet.payload, NotificationData::class.java)
                NotificationsActivity.notificationList.add(0, notif)
                runOnUiThread {
                    binding.tvLatestNotif.text = "🔔 ${notif.appName}: ${notif.title}"
                }
            }

            PacketType.PONG -> {
                runOnUiThread { binding.tvStatus.text = "Connected ✅ (ping OK)" }
            }

            PacketType.FILE_LIST_RES, PacketType.FILE_CHUNK -> {
                // Forwarded to FileBrowserActivity via ClientState listener
                ClientState.filePacketListener?.invoke(packet, binary)
            }
        }
    }

    private fun handleTouchOnScreen(viewW: Float, viewH: Float, event: MotionEvent) {
        if (socketManager == null) return
        val scaleX = remoteWidth  / viewW.coerceAtLeast(1f)
        val scaleY = remoteHeight / viewH.coerceAtLeast(1f)
        val rx = event.x * scaleX
        val ry = event.y * scaleY

        val touchData = when (event.action) {
            MotionEvent.ACTION_DOWN,
            MotionEvent.ACTION_UP   -> TouchEventData("TAP",   rx, ry)
            MotionEvent.ACTION_MOVE -> TouchEventData("SWIPE", rx, ry, rx, ry)
            else -> return
        }
        socketManager?.sendPacket(Packet(PacketType.TOUCH_EVENT, gson.toJson(touchData)))
    }

    override fun onDestroy() {
        super.onDestroy()
        disconnect()
    }
}

/** Singleton — shares the socket across all activities */
object ClientState {
    var socketManager: SocketManager? = null
    // FIX: added file packet listener so FileBrowserActivity receives packets
    var filePacketListener: ((Packet, ByteArray?) -> Unit)? = null
}
