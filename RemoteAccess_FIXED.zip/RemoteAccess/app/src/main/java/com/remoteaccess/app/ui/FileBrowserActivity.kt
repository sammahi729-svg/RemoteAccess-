package com.remoteaccess.app.ui

import android.os.Bundle
import android.view.LayoutInflater
import android.view.ViewGroup
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.DividerItemDecoration
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.gson.Gson
import com.remoteaccess.app.databinding.ActivityFileBrowserBinding
import com.remoteaccess.app.databinding.ItemFileBinding
import com.remoteaccess.app.models.*
import com.remoteaccess.app.network.Packet
import com.remoteaccess.app.network.PacketType
import java.io.File
import java.text.SimpleDateFormat
import java.util.*

class FileBrowserActivity : AppCompatActivity() {

    private lateinit var binding: ActivityFileBrowserBinding
    private val gson    = Gson()
    private val adapter = FileAdapter()
    private var currentPath = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityFileBrowserBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.rvFiles.layoutManager = LinearLayoutManager(this)
        binding.rvFiles.addItemDecoration(DividerItemDecoration(this, DividerItemDecoration.VERTICAL))
        binding.rvFiles.adapter = adapter

        binding.btnBack.setOnClickListener {
            val parent = File(currentPath).parent ?: ""
            requestFileList(parent)
        }

        // FIX: register listener on ClientState instead of overwriting the socket's callback
        ClientState.filePacketListener = { packet, binary ->
            when (packet.type) {
                PacketType.FILE_LIST_RES -> {
                    val res = gson.fromJson(packet.payload, FileListResponse::class.java)
                    currentPath = res.path
                    runOnUiThread {
                        binding.tvCurrentPath.text = res.path
                        adapter.setItems(res.items)
                    }
                }
                PacketType.FILE_CHUNK -> {
                    if (binary != null) {
                        val meta = gson.fromJson(packet.payload, FileChunkMeta::class.java)
                        saveFile(meta.name, binary)
                    }
                }
            }
        }

        requestFileList("")
    }

    private fun requestFileList(path: String) {
        ClientState.socketManager?.sendPacket(
            Packet(PacketType.FILE_LIST_REQ, gson.toJson(FileListRequest(path)))
        ) ?: Toast.makeText(this, "Not connected to server", Toast.LENGTH_SHORT).show()
    }

    private fun downloadFile(path: String) {
        // FIX: was using mapOf() which produced wrong JSON — now uses proper data class
        ClientState.socketManager?.sendPacket(
            Packet(PacketType.FILE_DOWNLOAD_REQ, gson.toJson(FileDownloadRequest(path)))
        )
        Toast.makeText(this, "Downloading...", Toast.LENGTH_SHORT).show()
    }

    private fun saveFile(name: String, data: ByteArray) {
        try {
            val dest = File(getExternalFilesDir(null), "RemoteAccess/$name")
            dest.parentFile?.mkdirs()
            dest.writeBytes(data)
            runOnUiThread {
                Toast.makeText(this, "✅ Saved to: ${dest.absolutePath}", Toast.LENGTH_LONG).show()
            }
        } catch (e: Exception) {
            runOnUiThread { Toast.makeText(this, "Save failed: ${e.message}", Toast.LENGTH_SHORT).show() }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        ClientState.filePacketListener = null       // FIX: always clean up listener
    }

    // ── Adapter ───────────────────────────────────────────────────────────────
    inner class FileAdapter : RecyclerView.Adapter<FileAdapter.VH>() {
        private val items = mutableListOf<FileItem>()
        private val sdf   = SimpleDateFormat("dd MMM yyyy  HH:mm", Locale.getDefault())

        fun setItems(list: List<FileItem>) {
            items.clear()
            items.addAll(
                list.sortedWith(compareByDescending<FileItem> { it.isDirectory }.thenBy { it.name })
            )
            notifyDataSetChanged()
        }

        inner class VH(val b: ItemFileBinding) : RecyclerView.ViewHolder(b.root)

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) =
            VH(ItemFileBinding.inflate(LayoutInflater.from(parent.context), parent, false))

        override fun getItemCount() = items.size

        override fun onBindViewHolder(holder: VH, position: Int) {
            val item = items[position]
            holder.b.tvFileName.text = (if (item.isDirectory) "📁 " else "📄 ") + item.name
            holder.b.tvFileInfo.text = if (item.isDirectory)
                sdf.format(Date(item.lastModified))
            else
                "${formatSize(item.size)}  •  ${sdf.format(Date(item.lastModified))}"

            holder.itemView.setOnClickListener {
                if (item.isDirectory) requestFileList(item.path)
                else downloadFile(item.path)
            }
        }

        private fun formatSize(bytes: Long): String = when {
            bytes < 1_024L             -> "$bytes B"
            bytes < 1_048_576L         -> "${bytes / 1_024} KB"
            bytes < 1_073_741_824L     -> "${"%.1f".format(bytes / 1_048_576f)} MB"
            else                       -> "${"%.2f".format(bytes / 1_073_741_824f)} GB"
        }
    }
}
