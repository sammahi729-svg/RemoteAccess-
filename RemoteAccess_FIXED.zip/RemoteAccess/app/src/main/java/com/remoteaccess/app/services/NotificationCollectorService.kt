package com.remoteaccess.app.services

import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import com.google.gson.Gson
import com.remoteaccess.app.models.NotificationData
import com.remoteaccess.app.network.Packet
import com.remoteaccess.app.network.PacketType

class NotificationCollectorService : NotificationListenerService() {

    private val gson = Gson()

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        val extras  = sbn.notification.extras
        val title   = extras.getString("android.title") ?: ""
        val text    = (extras.getCharSequence("android.text") ?: "").toString()
        val appName = try {
            packageManager.getApplicationLabel(
                packageManager.getApplicationInfo(sbn.packageName, 0)
            ).toString()
        } catch (e: Exception) { sbn.packageName }

        val data = NotificationData(
            appName = appName,
            title   = title,
            text    = text,
            time    = sbn.postTime
        )

        RemoteServerService.instance?.pendingNotifications?.add(data)
        RemoteServerService.instance?.broadcastPacket(
            Packet(PacketType.NOTIFICATION, gson.toJson(data))
        )
    }

    override fun onNotificationRemoved(sbn: StatusBarNotification) { }
}
