package com.remoteaccess.app.services

import android.app.*
import android.content.Intent
import android.os.*
import androidx.core.app.NotificationCompat
import com.google.gson.Gson
import com.remoteaccess.app.models.*
import com.remoteaccess.app.network.Packet
import com.remoteaccess.app.network.PacketType
import com.remoteaccess.app.network.SocketManager
import kotlinx.coroutines.*
import java.io.File
import java.net.ServerSocket
import java.net.Socket

class RemoteServerService : Service() {

    companion object {
        const val PORT          = 54321
        const val NOTIF_CHANNEL = "remote_server"
        const val NOTIF_ID      = 1
        var instance: RemoteServerService? = null
    }

    private val gson   = Gson()
    private val scope  = CoroutineScope(Dispatchers.IO + SupervisorJob())
    private var serverSocket: ServerSocket? = null
    private val clients = mutableListOf<SocketManager>()

    val pendingNotifications = mutableListOf<NotificationData>()

    override fun onCreate() {
        super.onCreate()
        instance = this
        createNotificationChannel()
        startForeground(NOTIF_ID, buildNotification("Waiting for connection..."))
        startAccepting()
    }

    private fun startAccepting() {
        scope.launch {
            try {
                serverSocket = ServerSocket(PORT)
                updateNotification("Server running on port $PORT")
                while (true) {
                    val socket: Socket = serverSocket?.accept() ?: break
                    handleClient(socket)
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    private fun handleClient(socket: Socket) {
        val manager = SocketManager(socket)
        synchronized(clients) { clients.add(manager) }
        updateNotification("Connected: ${socket.inetAddress.hostAddress}")

        manager.onDisconnected = {
            synchronized(clients) { clients.remove(manager) }
            updateNotification("Client disconnected. Waiting...")
        }
        manager.onPacketReceived = { packet, binary ->
            processPacket(manager, packet, binary)
        }
        manager.startListening()
        sendDeviceInfo(manager)
    }

    private fun processPacket(client: SocketManager, packet: Packet, binary: ByteArray?) {
        when (packet.type) {

            PacketType.PING -> {
                client.sendPacket(Packet(PacketType.PONG, "pong"))
            }

            PacketType.TOUCH_EVENT -> {
                val event = gson.fromJson(packet.payload, TouchEventData::class.java)
                simulateTouch(event)
            }

            PacketType.FILE_LIST_REQ -> {
                val req = gson.fromJson(packet.payload, FileListRequest::class.java)
                sendFileList(client, req.path)
            }

            PacketType.FILE_DOWNLOAD_REQ -> {
                val req = gson.fromJson(packet.payload, FileDownloadRequest::class.java)
                sendFile(client, req.path)
            }

            PacketType.FILE_UPLOAD_REQ -> {
                val req = gson.fromJson(packet.payload, FileUploadRequest::class.java)
                if (binary != null) saveUploadedFile(req.path, binary)
            }

            // FIX: START_CAMERA was not handled — caused camera button to do nothing
            PacketType.START_CAMERA -> {
                val req = gson.fromJson(packet.payload, StartCameraRequest::class.java)
                val intent = Intent(this, CameraStreamService::class.java).apply {
                    putExtra(CameraStreamService.EXTRA_CAMERA, req.cameraId)
                }
                startForegroundService(intent)
            }

            PacketType.STOP_CAMERA -> {
                stopService(Intent(this, CameraStreamService::class.java))
            }
        }
    }

    private fun sendDeviceInfo(client: SocketManager) {
        val info = DeviceInfo(
            model          = "${Build.MANUFACTURER} ${Build.MODEL}",
            androidVersion = Build.VERSION.RELEASE,
            sdkInt         = Build.VERSION.SDK_INT,
            ipAddress      = getLocalIp()
        )
        client.sendPacket(Packet(PacketType.DEVICE_INFO, gson.toJson(info)))
    }

    private fun sendFileList(client: SocketManager, path: String) {
        val dir = File(
            path.ifEmpty { Environment.getExternalStorageDirectory().absolutePath }
        )
        val items = if (dir.exists() && dir.isDirectory) {
            dir.listFiles()?.map {
                FileItem(
                    name         = it.name,
                    path         = it.absolutePath,
                    isDirectory  = it.isDirectory,
                    size         = if (it.isFile) it.length() else 0L,
                    lastModified = it.lastModified()
                )
            } ?: emptyList()
        } else emptyList()

        client.sendPacket(
            Packet(PacketType.FILE_LIST_RES, gson.toJson(FileListResponse(dir.absolutePath, items)))
        )
    }

    private fun sendFile(client: SocketManager, path: String) {
        scope.launch {
            val file = File(path)
            if (!file.exists() || !file.isFile) return@launch
            try {
                val bytes = file.readBytes()
                client.sendPacket(
                    Packet(PacketType.FILE_CHUNK, gson.toJson(FileChunkMeta(file.name, file.length())), bytes.size),
                    bytes
                )
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    private fun saveUploadedFile(path: String, data: ByteArray) {
        scope.launch {
            runCatching {
                val file = File(path)
                file.parentFile?.mkdirs()
                file.writeBytes(data)
            }
        }
    }

    private fun simulateTouch(event: TouchEventData) {
        scope.launch {
            try {
                val cmd = when (event.action) {
                    "TAP"   -> "input tap ${event.x.toInt()} ${event.y.toInt()}"
                    "SWIPE" -> "input swipe ${event.x.toInt()} ${event.y.toInt()} ${event.x2.toInt()} ${event.y2.toInt()} ${event.duration}"
                    "TEXT"  -> "input text '${event.text}'"
                    else    -> return@launch
                }
                Runtime.getRuntime().exec(arrayOf("su", "-c", cmd))
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    fun broadcastPacket(packet: Packet, binary: ByteArray? = null) {
        synchronized(clients) {
            clients.toList().forEach { it.sendPacket(packet, binary) }   // FIX: copy to avoid CME
        }
    }

    private fun createNotificationChannel() {
        val channel = NotificationChannel(NOTIF_CHANNEL, "Remote Server", NotificationManager.IMPORTANCE_LOW)
        getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
    }

    private fun buildNotification(text: String): Notification =
        NotificationCompat.Builder(this, NOTIF_CHANNEL)
            .setContentTitle("RemoteAccess Server")
            .setContentText(text)
            .setSmallIcon(android.R.drawable.ic_menu_share)
            .build()

    private fun updateNotification(text: String) {
        getSystemService(NotificationManager::class.java).notify(NOTIF_ID, buildNotification(text))
    }

    private fun getLocalIp(): String = try {
        val wm = applicationContext.getSystemService(android.net.wifi.WifiManager::class.java)
        val ip = wm.connectionInfo.ipAddress
        "${ip and 0xff}.${ip shr 8 and 0xff}.${ip shr 16 and 0xff}.${ip shr 24 and 0xff}"
    } catch (e: Exception) { "unknown" }

    override fun onDestroy() {
        super.onDestroy()
        scope.cancel()
        runCatching { serverSocket?.close() }
        synchronized(clients) { clients.forEach { it.close() } }
        instance = null
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
