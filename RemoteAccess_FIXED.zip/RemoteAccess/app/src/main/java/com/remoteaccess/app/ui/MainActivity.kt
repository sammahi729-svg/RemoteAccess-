package com.remoteaccess.app.ui

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.remoteaccess.app.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // This device acts as a SERVER (secondary device being controlled)
        binding.btnServer.setOnClickListener {
            startActivity(Intent(this, ServerActivity::class.java))
        }

        // This device acts as a CLIENT (main device doing the controlling)
        binding.btnClient.setOnClickListener {
            startActivity(Intent(this, ClientActivity::class.java))
        }
    }
}
