package com.remoteaccess.app.models

// ─── All shared data classes in one place ─────────────────────────────────────
// This fixes the bug where data classes were scattered across service files
// causing import errors and "Unresolved reference" build failures.

data class DeviceInfo(
    val model: String,
    val androidVersion: String,
    val sdkInt: Int,
    val ipAddress: String
)

data class TouchEventData(
    val action: String,
    val x: Float = 0f,
    val y: Float = 0f,
    val x2: Float = 0f,
    val y2: Float = 0f,
    val duration: Int = 300,
    val text: String = ""
)

data class FileListRequest(val path: String = "")

data class FileListResponse(
    val path: String,
    val items: List<FileItem>
)

data class FileItem(
    val name: String,
    val path: String,
    val isDirectory: Boolean,
    val size: Long,
    val lastModified: Long
)

data class FileDownloadRequest(val path: String)

data class FileUploadRequest(val path: String, val fileName: String)

data class FileChunkMeta(val name: String, val totalSize: Long)

data class NotificationData(
    val appName: String,
    val title: String,
    val text: String,
    val time: Long
)

data class ScreenFrameMeta(val width: Int, val height: Int, val byteSize: Int)

data class CameraFrameMeta(val width: Int, val height: Int, val byteSize: Int)

data class StartCameraRequest(val cameraId: String = "1")
