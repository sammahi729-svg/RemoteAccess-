package com.remoteaccess.app.services

import android.annotation.SuppressLint
import android.app.*
import android.content.Intent
import android.graphics.ImageFormat
import android.hardware.camera2.*
import android.media.ImageReader
import android.os.*
import androidx.core.app.NotificationCompat
import com.google.gson.Gson
import com.remoteaccess.app.models.CameraFrameMeta
import com.remoteaccess.app.network.Packet
import com.remoteaccess.app.network.PacketType

class CameraStreamService : Service() {

    companion object {
        const val EXTRA_CAMERA  = "camera_id"
        const val NOTIF_CHANNEL = "camera_stream"
        const val NOTIF_ID      = 3
    }

    private val gson    = Gson()
    private var cameraDevice: CameraDevice?             = null
    private var captureSession: CameraCaptureSession?   = null
    private var imageReader: ImageReader?               = null
    private val handlerThread = HandlerThread("CameraThread").also { it.start() }
    private val handler = Handler(handlerThread.looper)

    @SuppressLint("MissingPermission")
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        createNotificationChannel()
        startForeground(NOTIF_ID, buildNotification())

        val cameraId = intent?.getStringExtra(EXTRA_CAMERA) ?: "1"
        openCamera(cameraId)
        return START_STICKY
    }

    @SuppressLint("MissingPermission")
    private fun openCamera(cameraId: String) {
        val manager = getSystemService(CAMERA_SERVICE) as CameraManager

        imageReader = ImageReader.newInstance(640, 480, ImageFormat.JPEG, 2)
        imageReader!!.setOnImageAvailableListener({ reader ->
            val image = reader.acquireLatestImage() ?: return@setOnImageAvailableListener
            try {
                val buffer = image.planes[0].buffer
                val bytes  = ByteArray(buffer.remaining())
                buffer.get(bytes)
                broadcastFrame(bytes)
            } finally {
                image.close()
            }
        }, handler)

        manager.openCamera(cameraId, object : CameraDevice.StateCallback() {
            override fun onOpened(camera: CameraDevice) {
                cameraDevice = camera
                startPreview()
            }
            override fun onDisconnected(camera: CameraDevice) { camera.close() }
            override fun onError(camera: CameraDevice, error: Int) { camera.close() }
        }, handler)
    }

    private fun startPreview() {
        val surface = imageReader!!.surface
        cameraDevice?.createCaptureSession(
            listOf(surface),
            object : CameraCaptureSession.StateCallback() {
                override fun onConfigured(session: CameraCaptureSession) {
                    captureSession = session
                    val request = cameraDevice!!
                        .createCaptureRequest(CameraDevice.TEMPLATE_PREVIEW)
                        .apply { addTarget(surface) }
                        .build()
                    session.setRepeatingRequest(request, null, handler)
                }
                override fun onConfigureFailed(session: CameraCaptureSession) {}
            },
            handler
        )
    }

    private fun broadcastFrame(jpegBytes: ByteArray) {
        val meta = CameraFrameMeta(640, 480, jpegBytes.size)
        RemoteServerService.instance?.broadcastPacket(
            Packet(PacketType.CAMERA_FRAME, gson.toJson(meta), jpegBytes.size),
            jpegBytes
        )
    }

    private fun createNotificationChannel() {
        val channel = NotificationChannel(NOTIF_CHANNEL, "Camera Stream", NotificationManager.IMPORTANCE_LOW)
        getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
    }

    private fun buildNotification(): Notification =
        NotificationCompat.Builder(this, NOTIF_CHANNEL)
            .setContentTitle("Camera Streaming")
            .setContentText("Camera stream is active")
            .setSmallIcon(android.R.drawable.ic_menu_camera)
            .build()

    override fun onDestroy() {
        super.onDestroy()
        captureSession?.close()
        cameraDevice?.close()
        imageReader?.close()
        handlerThread.quitSafely()
    }

    override fun onBind(intent: Intent?) = null
}
