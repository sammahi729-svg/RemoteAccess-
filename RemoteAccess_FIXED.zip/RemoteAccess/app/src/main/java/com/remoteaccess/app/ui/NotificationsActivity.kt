package com.remoteaccess.app.ui

import android.os.Bundle
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.DividerItemDecoration
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.remoteaccess.app.databinding.ActivityNotificationsBinding
import com.remoteaccess.app.databinding.ItemNotificationBinding
import com.remoteaccess.app.models.NotificationData
import java.text.SimpleDateFormat
import java.util.*

class NotificationsActivity : AppCompatActivity() {

    companion object {
        // FIX: use thread-safe list
        val notificationList = Collections.synchronizedList(mutableListOf<NotificationData>())
    }

    private lateinit var binding: ActivityNotificationsBinding
    private val adapter = NotifAdapter()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityNotificationsBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.rvNotifications.layoutManager = LinearLayoutManager(this)
        binding.rvNotifications.addItemDecoration(
            DividerItemDecoration(this, DividerItemDecoration.VERTICAL)
        )
        binding.rvNotifications.adapter = adapter
        adapter.setItems(notificationList.toList())

        binding.btnClear.setOnClickListener {
            notificationList.clear()
            adapter.setItems(emptyList())
        }
    }

    inner class NotifAdapter : RecyclerView.Adapter<NotifAdapter.VH>() {
        private val items = mutableListOf<NotificationData>()
        private val sdf   = SimpleDateFormat("HH:mm:ss", Locale.getDefault())

        fun setItems(list: List<NotificationData>) {
            items.clear(); items.addAll(list); notifyDataSetChanged()
        }

        inner class VH(val b: ItemNotificationBinding) : RecyclerView.ViewHolder(b.root)

        override fun onCreateViewHolder(p: ViewGroup, t: Int) =
            VH(ItemNotificationBinding.inflate(LayoutInflater.from(p.context), p, false))

        override fun getItemCount() = items.size

        override fun onBindViewHolder(h: VH, pos: Int) {
            val n = items[pos]
            h.b.tvApp.text   = n.appName
            h.b.tvTitle.text = n.title.ifEmpty { "(no title)" }
            h.b.tvText.text  = n.text.ifEmpty  { "(no body)" }
            h.b.tvTime.text  = sdf.format(Date(n.time))
        }
    }
}
